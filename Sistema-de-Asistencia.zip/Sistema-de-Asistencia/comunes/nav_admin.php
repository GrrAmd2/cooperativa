   <!-- Navigation -->
    <nav id="mainNav" class="navbar navbar-default navbar-fixed-top navbar-custom">
        <div class="container">
            <!-- Brand and toggle get grouped for better mobile display -->
            
 
   <ul class="nav nav-pills">
     
        <li class="navbar-brand"><?php include("nombre.php"); ?></a></li>
      
        <li class="dropdown pull-right">
            <a href="#" data-toggle="dropdown" class="dropdown-toggle">Admin <b class="caret"></b></a>
            <ul class="dropdown-menu">
                  <li><a href="inicio_admin.php">Inicio</a></li>
                <li><a href="cerrar_sesion.php">Salir</a></li>
            </ul>
        </li>
    </ul>
               </div>
                    <!-- /.container-fluid -->
    </nav>