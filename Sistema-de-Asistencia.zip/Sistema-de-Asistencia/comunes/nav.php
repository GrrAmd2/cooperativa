    <!-- Navigation -->
    <nav id="mainNav" class="navbar navbar-default navbar-fixed-top navbar-custom">
        <div class="container">
            <!-- Brand and toggle get grouped for better mobile display -->
            <div class="navbar-header page-scroll" >
              
              <div style="text-align:center; "><a class="navbar-brand"  ><?php include("nombre.php"); ?></a> </div>
            </div>

            <!-- Collect the nav links, forms, and other content for toggling -->
            
            <!-- /.navbar-collapse -->
        </div>

        
        <!-- /.container-fluid -->
    </nav>
