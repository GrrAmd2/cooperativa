<!-- Footer -->
    <footer class="text-center">
         
        <div class="footer-below" style="background-color: black;width: 100%;color:white">
           
                     <?php include("nombre.php"); ?>
                   
        </div>
 </footer>
