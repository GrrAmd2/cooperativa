<!DOCTYPE html>
<html lang="en">
 
<?php
require("comunes/head.php");
require("permisos.php");
?>

<body >
 
<?php   require("comunes/nav_admin.php"); ?>

    <!-- Header -->
    <header>
     <br><br><br>

						  <div align="center">
                           <h1>Bienvenido </h1>
                           <br>
 <a href="empleados/index.php" title="Empleados"><img style="width:128px" src="img/empleados.png"/></a> <a href="marcados/index.php" title="Marcados"><img style="width:128px" src="img/marcados.png"/></a></div>
 
       <br> 
    </header>

 <?php   require("comunes/footer.php"); ?>
 <?php   require("comunes/scripts.php"); ?>

</body>
 
</html>
